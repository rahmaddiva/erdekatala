<?= $this->extend('templates/main') ?>
<?= $this->section('content') ?>

<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0"><i class="fas fa-chart-line mr-2"></i><?= esc($title) ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">

            <!-- Filter Card dengan Chained Dropdown -->
            <div class="card card-outline card-primary shadow-sm mb-4">
                <div class="card-header">
                    <h3 class="card-title"><i class="fas fa-filter mr-2"></i>Filter Wilayah</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse">
                            <i class="fas fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <form action="/dashboard" method="get" id="filterForm">
                        <div class="row">
                            <?php if (session()->get('role') == 'admin_dinas'): ?>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label><i class="fas fa-map-marked-alt mr-1"></i>Kecamatan</label>
                                            <select name="id_kecamatan" id="filter_kecamatan" class="form-control select2bs4">
                                                <option value="">-- Semua Kecamatan --</option>
                                                <?php foreach ($list_kecamatan as $k): ?>
                                                        <option value="<?= $k['id_kecamatan'] ?>" <?= ($filter_kec == $k['id_kecamatan']) ? 'selected' : '' ?>>
                                                            <?= $k['nama_kecamatan'] ?>
                                                        </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                            <?php endif; ?>

                            <?php if (session()->get('role') == 'admin_dinas' || session()->get('role') == 'admin_kecamatan'): ?>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label><i class="fas fa-map-marker-alt mr-1"></i>Desa</label>
                                            <select name="id_desa" id="filter_desa" class="form-control select2bs4">
                                                <option value="">-- Semua Desa --</option>
                                                <?php foreach ($list_desa as $d): ?>
                                                        <option value="<?= $d['id_desa'] ?>" <?= ($filter_desa == $d['id_desa']) ? 'selected' : '' ?>>
                                                            <?= $d['nama_desa'] ?>
                                                        </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                            <?php endif; ?>

                            <div class="col-md-1">
                                <div class="form-group">
                                    <label>&nbsp;</label>
                                    <button type="submit" class="btn btn-primary btn-block">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <?php
            $namaPeriode = ($bulanList[$bulanNow] ?? $bulanNow) . ' ' . $tahunNow;
            $persenLapor = $desaTotal > 0 ? round($desaSudahLapor / $desaTotal * 100) : 0;
            ?>

            <!-- Panel: Status Belum Lapor -->
            <?php if ($role === 'admin_desa' && $statusDesaSendiri): ?>
                <?php if (!$statusDesaSendiri['sudah_lapor']): ?>
                <div class="alert alert-warning alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <h5><i class="icon fas fa-exclamation-triangle"></i> Belum Lapor</h5>
                    Desa Anda belum menginput laporan untuk periode <strong><?= esc($namaPeriode) ?></strong>.
                    <a href="/laporan/input" class="btn btn-sm btn-warning ml-2"><i class="fas fa-plus"></i> Input Sekarang</a>
                </div>
                <?php else: ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <h5><i class="icon fas fa-check"></i> Sudah Lapor</h5>
                    Laporan periode <strong><?= esc($namaPeriode) ?></strong> sudah diinput.
                    <a href="/laporan/edit/<?= $statusDesaSendiri['id_laporan'] ?>" class="btn btn-sm btn-outline-success ml-2"><i class="fas fa-edit"></i> Edit</a>
                </div>
                <?php endif; ?>
            <?php elseif (in_array($role, ['admin_kecamatan', 'admin_dinas'], true)): ?>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <div class="info-box shadow-sm">
                            <span class="info-box-icon <?= $persenLapor == 100 ? 'bg-success' : ($persenLapor >= 50 ? 'bg-warning' : 'bg-danger') ?>">
                                <i class="fas fa-clipboard-check"></i>
                            </span>
                            <div class="info-box-content">
                                <span class="info-box-text">Capaian Lapor (<?= esc($namaPeriode) ?>)</span>
                                <span class="info-box-number"><?= $desaSudahLapor ?> / <?= $desaTotal ?> desa</span>
                                <div class="progress mt-1" style="height:6px">
                                    <div class="progress-bar bg-<?= $persenLapor == 100 ? 'success' : 'warning' ?>" style="width:<?= $persenLapor ?>%"></div>
                                </div>
                                <small class="text-muted"><?= $persenLapor ?>% desa sudah lapor</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card card-outline card-danger shadow-sm mb-0">
                            <div class="card-header py-2">
                                <h3 class="card-title text-sm">
                                    <i class="fas fa-exclamation-circle mr-1"></i>
                                    Desa Belum Lapor (<?= count($desaBelumLapor) ?>)
                                </h3>
                            </div>
                            <div class="card-body py-2" style="max-height:120px;overflow-y:auto">
                                <?php if (empty($desaBelumLapor)): ?>
                                    <span class="text-success"><i class="fas fa-check"></i> Semua desa sudah lapor.</span>
                                <?php else: ?>
                                    <?php foreach ($desaBelumLapor as $d): ?>
                                        <span class="badge badge-danger mr-1 mb-1"><?= esc($d['nama_desa']) ?><?= $role === 'admin_dinas' ? ' (' . esc($d['nama_kecamatan']) . ')' : '' ?></span>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if (!empty($anomali)): ?>
                <div class="card card-outline card-warning shadow-sm mb-3">
                    <div class="card-header py-2">
                        <h3 class="card-title text-sm">
                            <i class="fas fa-chart-line mr-1"></i>
                            Alert Anomali Jiwa (±20% vs bulan lalu) — <?= count($anomali) ?> desa
                        </h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-sm table-hover mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th>Desa</th>
                                        <?php if ($role === 'admin_dinas'): ?><th>Kecamatan</th><?php endif; ?>
                                        <th class="text-right">Jiwa Lalu</th>
                                        <th class="text-right">Jiwa Sekarang</th>
                                        <th class="text-right">Selisih</th>
                                        <th class="text-right">%</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach (array_slice($anomali, 0, 15) as $a): ?>
                                    <tr>
                                        <td><?= esc($a['nama_desa']) ?></td>
                                        <?php if ($role === 'admin_dinas'): ?><td><?= esc($a['nama_kecamatan']) ?></td><?php endif; ?>
                                        <td class="text-right"><?= number_format($a['jiwa_sebelum']) ?></td>
                                        <td class="text-right"><?= number_format($a['jiwa_sekarang']) ?></td>
                                        <td class="text-right <?= $a['selisih'] > 0 ? 'text-success' : 'text-danger' ?>">
                                            <?= $a['selisih'] > 0 ? '+' : '' ?><?= number_format($a['selisih']) ?>
                                        </td>
                                        <td class="text-right">
                                            <span class="badge badge-<?= abs($a['persen_perubahan']) >= 50 ? 'danger' : 'warning' ?>">
                                                <?= $a['persen_perubahan'] > 0 ? '+' : '' ?><?= $a['persen_perubahan'] ?>%
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php if (count($anomali) > 15): ?>
                        <div class="card-footer py-1"><small class="text-muted">Menampilkan 15 dari <?= count($anomali) ?> anomali.</small></div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            <?php endif; ?>

            <!-- Info Boxes - Statistik Utama -->
            <div class="row">
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="info-box shadow-sm">
                        <span class="info-box-icon bg-gradient-primary elevation-1">
                            <i class="fas fa-users"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-text">Total Penduduk</span>
                            <span class="info-box-number">
                                <?= number_format($totals['jiwa_l'] + $totals['jiwa_p']) ?>
                            </span>
                            <small class="text-muted">
                                <i class="fas fa-male text-info"></i> <?= number_format($totals['jiwa_l']) ?> | 
                                <i class="fas fa-female text-danger"></i> <?= number_format($totals['jiwa_p']) ?>
                            </small>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-3">
                    <div class="info-box shadow-sm">
                        <span class="info-box-icon bg-gradient-success elevation-1">
                            <i class="fas fa-home"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-text">Total Kepala Keluarga</span>
                            <span class="info-box-number">
                                <?= number_format($totals['kk_l'] + $totals['kk_p']) ?>
                            </span>
                            <small class="text-muted">
                                KK Laki: <?= number_format($totals['kk_l']) ?> | 
                                KK Perempuan: <?= number_format($totals['kk_p']) ?>
                            </small>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-3">
                    <div class="info-box shadow-sm">
                        <span class="info-box-icon bg-gradient-warning elevation-1">
                            <i class="fas fa-baby"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-text">Balita (0-5 Tahun)</span>
                            <span class="info-box-number">
                                <?= number_format($totals['balita']) ?>
                            </span>
                            <small class="text-muted">Anak usia 0-5 tahun</small>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-3">
                    <div class="info-box shadow-sm">
                        <span class="info-box-icon bg-gradient-danger elevation-1">
                            <i class="fas fa-heart"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-text">Pasangan Usia Subur</span>
                            <span class="info-box-number">
                                <?= number_format($totals['pus']) ?>
                            </span>
                            <small class="text-muted">PUS aktif</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tabel Ringkasan per Wilayah -->
            <?php if (!empty($data_summary)): ?>
                <div class="card card-outline card-info shadow-sm">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-table mr-2"></i>
                            Ringkasan Data 
                            <?php if ($filter_desa): ?>
                                    Desa Terpilih
                            <?php elseif ($filter_kec): ?>
                                    Per Desa
                            <?php else: ?>
                                    Per Kecamatan
                            <?php endif; ?>
                        </h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover m-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th>Wilayah</th>
                                        <th class="text-center">Total KK</th>
                                        <th class="text-center">Total Jiwa</th>
                                        <th class="text-center">Laki-laki</th>
                                        <th class="text-center">Perempuan</th>
                                        <th class="text-center">Balita</th>
                                        <th class="text-center">PUS</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($data_summary as $s): ?>
                                            <tr>
                                                <td>
                                                    <strong>
                                                        <?= $s['nama_kecamatan'] ?? $s['nama_desa'] ?? '-' ?>
                                                    </strong>
                                                </td>
                                                <td class="text-center">
                                                    <span class="badge badge-success">
                                                        <?= number_format($s['total_kk']) ?>
                                                    </span>
                                                </td>
                                                <td class="text-center">
                                                    <strong><?= number_format($s['total_jiwa']) ?></strong>
                                                </td>
                                                <td class="text-center">
                                                    <i class="fas fa-male text-info"></i> 
                                                    <?= number_format($s['total_jiwa_l']) ?>
                                                </td>
                                                <td class="text-center">
                                                    <i class="fas fa-female text-danger"></i> 
                                                    <?= number_format($s['total_jiwa_p']) ?>
                                                </td>
                                                <td class="text-center">
                                                    <?= number_format($s['total_balita']) ?>
                                                </td>
                                                <td class="text-center">
                                                    <?= number_format($s['total_pus']) ?>
                                                </td>
                                            </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Grafik Statistik -->
            <div class="row">
                <!-- Piramida Penduduk -->
                <div class="col-md-12">
                    <div class="card card-danger shadow-sm">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-chart-bar mr-2"></i>Piramida Penduduk</h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div id="chartPiramida"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Tingkat Pendidikan -->
                <div class="col-md-6">
                    <div class="card card-info shadow-sm">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-graduation-cap mr-2"></i>Tingkat Pendidikan</h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div id="chartPendidikan"></div>
                        </div>
                    </div>
                </div>

                <!-- Status Perkawinan -->
                <div class="col-md-6">
                    <div class="card card-warning shadow-sm">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-ring mr-2"></i>Status Perkawinan</h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div id="chartKawin"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Jenis Pekerjaan -->
                <div class="col-md-12">
                    <div class="card card-success shadow-sm">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-briefcase mr-2"></i>Jenis Pekerjaan</h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div id="chartPekerjaan"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8">
                    <div class="card card-outline card-primary shadow">
                        <div class="card-header">
                            <h3 class="card-title">Statistik Jiwa & Kepala Keluarga (Gender)</h3>
                        </div>
                        <div class="card-body">
                            <div id="chartGender"></div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card card-outline card-success shadow">
                        <div class="card-header">
                            <h3 class="card-title">Capaian Dokumen Adminduk</h3>
                        </div>
                        <div class="card-body">
                            <div id="chartDokumen"></div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card card-outline card-info shadow">
                        <div class="card-header">
                            <h3 class="card-title">Distribusi JKN / BPJS</h3>
                        </div>
                        <div class="card-body">
                            <div id="chartBPJS"></div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
</div>

<script src="https://cdn.zingchart.com/zingchart.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function () {
    // --- ZingChart theme helpers ---
    const C = {
        blue:   '#3b82f6',
        pink:   '#ec4899',
        green:  '#10b981',
        amber:  '#f59e0b',
        red:    '#ef4444',
        cyan:   '#06b6d4',
        teal:   '#14b8a6',
        purple: '#8b5cf6',
        indigo: '#6366f1'
    };
    const BG   = '#1e2a38';
    const TEXT = '#e2e8f0';
    const GRID = '#2d3748';
    const FONT = { 'font-family': 'Source Sans Pro, sans-serif', 'font-size': '12px', 'font-color': TEXT };
    const TIP  = { 'font-color': '#fff', 'background-color': '#2d3748', 'border-radius': '4px', padding: '6px' };

    // ============================================================
    // 1. PIRAMIDA PENDUDUK — hbar stacked, L negatif / P positif
    // ============================================================
    const maleRaw    = <?= json_encode(array_map('intval', $piramidaL)) ?>;
    const femaleData = <?= json_encode(array_map('intval', $piramidaP)) ?>;
    const maleNeg    = maleRaw.map(v => -v);
    const ageLabels  = <?= json_encode($ageLabels) ?>;
    zingchart.render({
        id: 'chartPiramida',
        height: 530,
        data: {
            type: 'hbar',
            'background-color': BG,
            stacked: true,
            title: { visible: false },
            legend: {
                layout: 'x2', 'background-color': 'none', 'border-width': 0,
                item: Object.assign({}, FONT)
            },
            plot: {
                animation: { effect: 2, speed: 600 },
                'bar-width': '82%',
                tooltip: Object.assign({ text: '%t Umur %scale-key-text: %node-value orang' }, TIP)
            },
            'scale-x': { values: ageLabels, item: Object.assign({}, FONT), guide: { 'line-color': GRID } },
            'scale-y': {
                label: { text: 'Jumlah Penduduk', 'font-color': TEXT },
                item: Object.assign({}, FONT),
                guide: { 'line-color': GRID },
                format: '%v'
            },
            series: [
                { text: 'Laki-laki',  values: maleNeg,    'background-color': C.blue,  'legend-marker': { 'background-color': C.blue } },
                { text: 'Perempuan', values: femaleData, 'background-color': C.pink,  'legend-marker': { 'background-color': C.pink } }
            ]
        }
    });

    // ============================================================
    // 2. TINGKAT PENDIDIKAN KK — pie chart
    // ============================================================
    const pendLabels = <?= json_encode(array_keys($pendidikan)) ?>;
    const pendValues = <?= json_encode(array_values($pendidikan)) ?>;
    const pendColors = [C.indigo, C.purple, C.pink, C.amber, C.green, C.blue, C.cyan];
    zingchart.render({
        id: 'chartPendidikan',
        height: 380,
        data: {
            type: 'pie',
            'background-color': BG,
            title: { visible: false },
            plot: {
                'value-box': { text: '%npv%', 'font-size': '11px', 'font-color': '#fff', placement: 'out' },
                tooltip: Object.assign({ text: '%t\n%v KK (%npv%)' }, TIP),
                animation: { effect: 4, speed: 600 },
                slice: 70
            },
            legend: { layout: 'x3', 'background-color': 'none', 'border-width': 0, item: Object.assign({}, FONT) },
            series: pendValues.map((v, i) => ({
                text: pendLabels[i], values: [v],
                'background-color': pendColors[i % pendColors.length]
            }))
        }
    });

    // ============================================================
    // 3. STATUS PERKAWINAN KK — ring (donut) chart
    // ============================================================
    const kawinLabels = <?= json_encode(array_keys($status_kawin)) ?>;
    const kawinValues = <?= json_encode(array_values($status_kawin)) ?>;
    const kawinColors = [C.green, C.blue, C.amber, C.red];
    zingchart.render({
        id: 'chartKawin',
        height: 380,
        data: {
            type: 'ring',
            'background-color': BG,
            title: { visible: false },
            plot: {
                'value-box': { text: '%npv%', 'font-size': '11px', 'font-color': '#fff', placement: 'out' },
                tooltip: Object.assign({ text: '%t\n%v KK (%npv%)' }, TIP),
                animation: { effect: 4, speed: 600 },
                slice: 60
            },
            legend: { layout: 'x2', 'background-color': 'none', 'border-width': 0, item: Object.assign({}, FONT) },
            series: kawinValues.map((v, i) => ({
                text: kawinLabels[i], values: [v],
                'background-color': kawinColors[i % kawinColors.length]
            }))
        }
    });

    // ============================================================
    // 4. JENIS PEKERJAAN KK — hbar chart
    // ============================================================
    const pkLabels = <?= json_encode(array_keys($pekerjaan)) ?>;
    const pkValues = <?= json_encode(array_values($pekerjaan)) ?>;
    zingchart.render({
        id: 'chartPekerjaan',
        height: 400,
        data: {
            type: 'hbar',
            'background-color': BG,
            title: { visible: false },
            plot: {
                'background-color': C.green,
                'border-radius': '3px',
                animation: { effect: 2, speed: 500 },
                'value-box': { text: '%v KK', 'font-size': '11px', 'font-color': TEXT, placement: 'top-out' },
                tooltip: Object.assign({ text: '%t: %v KK' }, TIP)
            },
            'scale-x': { values: pkLabels, item: Object.assign({}, FONT), guide: { 'line-color': GRID } },
            'scale-y': { label: { text: 'Jumlah KK', 'font-color': TEXT }, item: Object.assign({}, FONT), guide: { 'line-color': GRID } },
            series: [{ text: 'Jumlah KK', values: pkValues }]
        }
    });

    // ============================================================
    // 5. GENDER JIWA & KK — grouped bar vertikal
    // ============================================================
    zingchart.render({
        id: 'chartGender',
        height: 350,
        data: {
            type: 'bar',
            'background-color': BG,
            title: { visible: false },
            plot: {
                'bar-width': '40%',
                'border-radius': '4px',
                animation: { effect: 5, speed: 500 },
                'value-box': { text: '%v', 'font-size': '11px', 'font-color': TEXT, placement: 'top' },
                tooltip: Object.assign({ text: '%t: %v orang' }, TIP)
            },
            'scale-x': { values: ['Jumlah Jiwa', 'Jumlah KK'], item: Object.assign({}, FONT), guide: { 'line-color': GRID } },
            'scale-y': { label: { text: 'Jumlah', 'font-color': TEXT }, item: Object.assign({}, FONT), guide: { 'line-color': GRID } },
            legend: { layout: 'x2', 'background-color': 'none', 'border-width': 0, item: Object.assign({}, FONT) },
            series: [
                { text: 'Laki-laki',  values: [<?= intval($grafik['gender']['jiwa_l']) ?>, <?= intval($grafik['gender']['kk_l']) ?>], 'background-color': C.blue, 'legend-marker': { 'background-color': C.blue } },
                { text: 'Perempuan', values: [<?= intval($grafik['gender']['jiwa_p']) ?>, <?= intval($grafik['gender']['kk_p']) ?>], 'background-color': C.pink, 'legend-marker': { 'background-color': C.pink } }
            ]
        }
    });

    // ============================================================
    // 6. DOKUMEN ADMINDUK — hbar chart
    // ============================================================
    zingchart.render({
        id: 'chartDokumen',
        height: 350,
        data: {
            type: 'hbar',
            'background-color': BG,
            title: { visible: false },
            plot: {
                'background-color': C.teal,
                'border-radius': '3px',
                animation: { effect: 2, speed: 500 },
                'value-box': { text: '%v', 'font-size': '11px', 'font-color': TEXT, placement: 'top-out' },
                tooltip: Object.assign({ text: '%t: %v orang' }, TIP)
            },
            'scale-x': { values: ['KTP-el', 'Akta Lahir', 'Akta Nikah', 'KK Fisik'], item: Object.assign({}, FONT), guide: { 'line-color': GRID } },
            'scale-y': { label: { text: 'Jumlah Penduduk', 'font-color': TEXT }, item: Object.assign({}, FONT), guide: { 'line-color': GRID } },
            series: [{ text: 'Pemilik Dokumen', values: [<?= intval($grafik['dokumen']['ktp_elektronik']) ?>, <?= intval($grafik['dokumen']['akta_lahir']) ?>, <?= intval($grafik['dokumen']['akta_nikah']) ?>, <?= intval($grafik['dokumen']['kk_fisik']) ?>] }]
        }
    });

    // ============================================================
    // 7. JKN / BPJS — ring chart
    // ============================================================
    zingchart.render({
        id: 'chartBPJS',
        height: 350,
        data: {
            type: 'ring',
            'background-color': BG,
            title: { visible: false },
            plot: {
                'value-box': { text: '%npv%', 'font-size': '11px', 'font-color': '#fff', placement: 'out' },
                tooltip: Object.assign({ text: '%t\n%v orang (%npv%)' }, TIP),
                animation: { effect: 4, speed: 600 },
                slice: 65
            },
            legend: { layout: 'x1', 'background-color': 'none', 'border-width': 0, item: Object.assign({}, FONT) },
            series: [
                { text: 'BPJS PBI (Bantuan)',     values: [<?= intval($grafik['bpjs']['pbi']) ?>],     'background-color': C.cyan },
                { text: 'BPJS Non-PBI (Mandiri)', values: [<?= intval($grafik['bpjs']['non_pbi']) ?>], 'background-color': C.teal },
                { text: 'Tidak Ber-JKN',           values: [<?= intval($grafik['bpjs']['non_jkn']) ?>], 'background-color': C.amber }
            ]
        }
    });

    // Chained dropdown: kecamatan → desa
    <?php if (session()->get('role') == 'admin_dinas'): ?>
        $('#filter_kecamatan').change(function() {
            const idKecamatan = $(this).val();
            $('#filter_desa').html('<option value="">-- Semua Desa --</option>');
            if (idKecamatan) {
                $.get('/dashboard/getDesaByKecamatan/' + idKecamatan, function(data) {
                    data.forEach(function(desa) {
                        $('#filter_desa').append(`<option value="${desa.id_desa}">${desa.nama_desa}</option>`);
                    });
                });
            }
        });
    <?php endif; ?>
});
</script>

<?= $this->endSection() ?>